/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 50728
 Source Host           : localhost:3306
 Source Schema         : dbshop

 Target Server Type    : MySQL
 Target Server Version : 50728
 File Encoding         : 65001

 Date: 29/11/2020 17:15:25
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ausertable
-- ----------------------------
DROP TABLE IF EXISTS `ausertable`;
CREATE TABLE `ausertable` (
  `aname` varchar(50) NOT NULL,
  `apwd` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`aname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ausertable
-- ----------------------------
BEGIN;
INSERT INTO `ausertable` VALUES ('admin', 'e10adc3949ba59abbe56e057f20f883e', 'admin');
COMMIT;

-- ----------------------------
-- Table structure for busertable
-- ----------------------------
DROP TABLE IF EXISTS `busertable`;
CREATE TABLE `busertable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bemail` varchar(50) NOT NULL,
  `bpwd` varchar(50) NOT NULL,
  PRIMARY KEY (`id`,`bemail`) USING BTREE,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for carttable
-- ----------------------------
DROP TABLE IF EXISTS `carttable`;
CREATE TABLE `carttable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `busertable_id` int(11) NOT NULL,
  `goodstable_id` int(11) NOT NULL,
  `shoppingnum` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `w2` (`busertable_id`),
  KEY `w3` (`goodstable_id`),
  CONSTRAINT `w2` FOREIGN KEY (`busertable_id`) REFERENCES `busertable` (`id`) ON DELETE CASCADE,
  CONSTRAINT `w3` FOREIGN KEY (`goodstable_id`) REFERENCES `goodstable` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for focustable
-- ----------------------------
DROP TABLE IF EXISTS `focustable`;
CREATE TABLE `focustable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goodstable_id` int(11) NOT NULL,
  `busertable_id` int(11) NOT NULL,
  `focustime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `w4` (`busertable_id`),
  KEY `w5` (`goodstable_id`),
  CONSTRAINT `w4` FOREIGN KEY (`busertable_id`) REFERENCES `busertable` (`id`) ON DELETE CASCADE,
  CONSTRAINT `w5` FOREIGN KEY (`goodstable_id`) REFERENCES `goodstable` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for goodstable
-- ----------------------------
DROP TABLE IF EXISTS `goodstable`;
CREATE TABLE `goodstable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gname` varchar(50) NOT NULL,
  `goprice` double(10,2) NOT NULL,
  `grprice` double(10,2) NOT NULL,
  `gstore` int(11) NOT NULL,
  `gpicture` varchar(50) DEFAULT NULL,
  `goodstype_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `w1` (`goodstype_id`),
  CONSTRAINT `w1` FOREIGN KEY (`goodstype_id`) REFERENCES `goodstype` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goodstable
-- ----------------------------
BEGIN;
INSERT INTO `goodstable` VALUES (1, '苹果', 100.00, 200.00, 100, NULL, 1);
INSERT INTO `goodstable` VALUES (2, '栗子', 100.00, 200.00, 100, NULL, 1);
INSERT INTO `goodstable` VALUES (3, 'iphone11', 5000.00, 6000.00, 200, NULL, 3);
INSERT INTO `goodstable` VALUES (4, '卫衣', 150.00, 150.00, 100, NULL, 2);
INSERT INTO `goodstable` VALUES (5, '衬衫', 200.00, 300.00, 100, NULL, 2);
INSERT INTO `goodstable` VALUES (6, '洗衣机', 300.00, 500.00, 100, NULL, 4);
INSERT INTO `goodstable` VALUES (7, '吹风机', 140.00, 200.00, 100, NULL, 4);
INSERT INTO `goodstable` VALUES (8, '橘子', 100.00, 200.00, 1000, NULL, 1);
INSERT INTO `goodstable` VALUES (9, '桃子', 100.00, 2000.00, 10, NULL, 1);
INSERT INTO `goodstable` VALUES (10, 'iPhone', 90.00, 90.00, 11, NULL, 3);
INSERT INTO `goodstable` VALUES (11, '哈密瓜', 100.00, 200.00, 1111, NULL, 1);
INSERT INTO `goodstable` VALUES (12, '黄瓜', 11.00, 111.00, 11, NULL, 1);
INSERT INTO `goodstable` VALUES (13, '香蕉', 200.00, 100.00, 111, NULL, 1);
INSERT INTO `goodstable` VALUES (14, 'mate40', 5000.00, 7000.00, 111, NULL, 3);
INSERT INTO `goodstable` VALUES (15, 'test', 1000.00, 1000.00, 11111, NULL, 1);
INSERT INTO `goodstable` VALUES (16, 'iwatch', 2000.00, 2000.00, 111, NULL, 3);
COMMIT;

-- ----------------------------
-- Table structure for goodstype
-- ----------------------------
DROP TABLE IF EXISTS `goodstype`;
CREATE TABLE `goodstype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typename` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goodstype
-- ----------------------------
BEGIN;
INSERT INTO `goodstype` VALUES (1, '水果');
INSERT INTO `goodstype` VALUES (2, '衣服');
INSERT INTO `goodstype` VALUES (3, '数码');
INSERT INTO `goodstype` VALUES (4, '生活');
COMMIT;

-- ----------------------------
-- Table structure for noticetable
-- ----------------------------
DROP TABLE IF EXISTS `noticetable`;
CREATE TABLE `noticetable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ntitle` varchar(100) NOT NULL,
  `ncontent` varchar(500) NOT NULL,
  `ntime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for orderbasetable
-- ----------------------------
DROP TABLE IF EXISTS `orderbasetable`;
CREATE TABLE `orderbasetable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `busertable_id` int(11) NOT NULL,
  `amount` double(10,0) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `orderdate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `w6` (`busertable_id`),
  CONSTRAINT `w6` FOREIGN KEY (`busertable_id`) REFERENCES `busertable` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderbasetable_id` int(11) NOT NULL,
  `goodstable_id` int(11) NOT NULL,
  `shoppingnum` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `w8` (`goodstable_id`),
  KEY `w7` (`orderbasetable_id`),
  CONSTRAINT `w7` FOREIGN KEY (`orderbasetable_id`) REFERENCES `orderbasetable` (`id`),
  CONSTRAINT `w8` FOREIGN KEY (`goodstable_id`) REFERENCES `goodstable` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for system_menu
-- ----------------------------
DROP TABLE IF EXISTS `system_menu`;
CREATE TABLE `system_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` varchar(100) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `href` varchar(100) NOT NULL DEFAULT '' COMMENT '链接',
  `target` varchar(20) NOT NULL DEFAULT '_self' COMMENT '链接打开方式',
  `sort` int(11) DEFAULT '0' COMMENT '菜单排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间',
  `delete_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `href` (`href`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统菜单表';

-- ----------------------------
-- Records of system_menu
-- ----------------------------
BEGIN;
INSERT INTO `system_menu` VALUES (1, 0, '商品管理', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (2, 0, '类型管理', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (3, 0, '用户管理', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (4, 0, '订单管理', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (5, 0, '公告管理', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (6, 0, '系统管理', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (7, 1, '添加商品', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (8, 1, '删除商品', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (9, 1, '修改商品', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (10, 1, '查询商品', '', '/ShoppingSystem_war/admin/togoodstable', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (11, 2, '添加类型', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `system_menu` VALUES (12, 2, '删除类型', '', '', '_self', 0, 1, NULL, NULL, NULL, NULL);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
